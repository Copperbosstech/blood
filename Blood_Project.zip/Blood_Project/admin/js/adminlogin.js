function closeAlert(id) {
    document.getElementById(id).style.display = 'none';
}

function redirectToDashboard() {
    setTimeout(function () {
        window.location.href = 'admin_dashboard.php';
    }, 2000); // Redirect after 2 seconds
}