<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'vendor/autoload.php'; // ✅ Load PHPMailer

function sendOTP($recipientEmail) {
    $otp = rand(100000, 999999); // ✅ Generate 6-digit OTP
    session_start();
    $_SESSION['otp'] = $otp; // ✅ Store OTP in session

    // ✅ SMTP Configuration
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'fwms5798@gmail.com';
        $mail->Password = 'veah agyg dibd treg'; // ✅ Decode Base64 password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // ✅ Email Settings
        $mail->setFrom('fwms5798@gmail.com', 'OTP MESSAGE');
        $mail->addAddress($recipientEmail);
        $mail->Subject = 'Your OTP Code';
        $mail->Body = "Hello,\n\nYour OTP code is: *$otp*\n\nThis code will expire in 5 minutes.";
        $mail->isHTML(false);

        $mail->send();
        return "OTP sent successfully to $recipientEmail!"; 
    } catch (Exception $e) {
        return "Error: " . $mail->ErrorInfo;
    }
}

// ✅ Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    echo sendOTP($email);
}
?>

<!-- ✅ HTML Form -->
<!DOCTYPE html>
<html>
<head>
    <title>Send OTP</title>
</head>
<body>
    <form method="POST">
        <label>Enter Email:</label>
        <input type="email" name="email" required>
        <button type="submit">Send OTP</button>
    </form>
</body>
</html>
