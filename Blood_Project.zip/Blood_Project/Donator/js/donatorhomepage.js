function loadPage(page, element) {
    event.preventDefault(); // Prevent default anchor behavior

    var iframe = document.getElementById("content-container");
    iframe.src = page; // Load page inside iframe

    // Remove 'active' class from all links
    var links = document.querySelectorAll(".sidebar a");
    links.forEach(link => link.classList.remove("active"));

    // Add 'active' class to clicked link
    element.classList.add("active");
}