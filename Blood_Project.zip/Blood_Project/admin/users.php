<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "usersignup");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle delete request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']); // Secure against SQL injection
    $deleteQuery = "DELETE FROM table1 WHERE id = $id";
    if (mysqli_query($conn, $deleteQuery)) {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                showCustomAlert('User deleted successfully!', 'success');
            });
        </script>";
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                showCustomAlert('Error deleting user.', 'danger');
            });
        </script>";
    }
}

// Fetch users from database
$sql = "SELECT * FROM table1";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users List</title>

    <style>
        * {
            font-family: Arial, sans-serif;
        }

        .container {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background: #2c3e50;
            color: white;
        }

        .btn {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
            color: white;
            display: inline-block;
        }

        .view-btn {
            background: transparent;
        }

        .delete-btn {
            background: transparent;
        }

        .btn:hover {
            opacity: 0.8;
        }

        /* Custom Alert Box */
        .custom-alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.3);
            text-align: center;
            min-width: 250px;
            max-width: 80%;
            z-index: 1000;
            font-size: 16px;
            font-weight: bold;
            display: none;
        }

        .success { border-left: 5px solid green; color: green; }
        .danger { border-left: 5px solid red; color: red; }

        .alert-close-btn {
            margin-top: 10px;
            padding: 5px 10px;
            background: #2c3e50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

    </style>
</head>
<body>

    <div class="container">
        <h2>Users List</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>

            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['gender']}</td>
                        <td>{$row['address']}</td>
                        <td>{$row['phone']}</td>
                        <td>{$row['email']}</td>
                        <td>
                            <a href='view_user.php?id={$row['id']}' class='btn view-btn'>
                                <img src='images/view.png' alt='View' width='40' height='40'>
                            </a>
                            
                            <a href='users.php?delete={$row['id']}' class='btn delete-btn' 
                                onclick='return confirmDelete(event, {$row['id']})'>
                                <img src='images/delete.png' alt='Delete' width='40' height='40'>
                            </a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No users found</td></tr>";
            }

            // Close connection
            mysqli_close($conn);
            ?>
        </table>
    </div>

    <!-- Custom Alert Box -->
    <div id="customAlert" class="custom-alert">
        <p id="alertMessage"></p>
        <button class="alert-close-btn" onclick="closeCustomAlert()">OK</button>
    </div>

    <script>
        function showCustomAlert(message, type) {
            var alertBox = document.getElementById('customAlert');
            var alertMessage = document.getElementById('alertMessage');
            alertBox.classList.remove('success', 'danger'); // Remove previous styles
            alertBox.classList.add(type); // Add new style
            alertMessage.innerText = message;
            alertBox.style.display = 'block';
        }

        function closeCustomAlert() {
            document.getElementById('customAlert').style.display = 'none';
            window.location.href = 'users.php'; // Refresh page after closing alert
        }

        function confirmDelete(event, id) {
            event.preventDefault();
            showCustomAlert('Are you sure you want to delete this user?', 'danger');
            document.querySelector('.alert-close-btn').onclick = function () {
                window.location.href = 'users.php?delete=' + id;
            };
        }
    </script>

<a href="admin_dashboard.html" class="back-btn">Back to Dashboard</a>
</body>
</html>
