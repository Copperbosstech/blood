<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <script>
        function closeAlert(id) {
            document.getElementById(id).style.display = 'none';
        }

        function redirectToDashboard() {
            setTimeout(function () {
                window.location.href = 'admin_dashboard.php';
            }, 2000); // Redirect after 2 seconds
        }
    </script>

    <style>
        .custom-alert {
            padding: 15px;
            margin: 20px auto;
            border-radius: 5px;
            width: 50%;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }
        .success {
            background-color: #4CAF50;
            color: white;
        }
        .error {
            background-color: #ff4d4d;
            color: white;
        }
        .close-btn {
            float: right;
            background: none;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }
        .message {
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            color: green;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<?php
// Start the session
session_start();

// Redirect if already logged in
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: admin_dashboard.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == 'POST') {
    // Get the submitted form values
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Setting default username and password
    $admin_username = "bloodadmin";
    $admin_password = "bloodpassword";

    // Validating credentials
    if ($username === $admin_username && $password === $admin_password) {
        // Set session variable
        $_SESSION['admin_logged_in'] = true;

        // Show success message and redirect
        echo '<div id="success" class="custom-alert">
                <button class="close-btn" onclick="closeAlert(\'successAlert\')">✖</button>
                <p>✅ Success! Redirecting to Dashboard...</p>
              </div>';
        echo "<script>redirectToDashboard();</script>";
    } else {
        // Error message in red
        echo "<p class='message' style='color: red;'>❌ Invalid Username or Password</p>";
    }
}
?>

</body>
</html>
