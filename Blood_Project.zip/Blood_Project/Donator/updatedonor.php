<style>
    .custom-alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.3);
            display: none;
            text-align: center;
            min-width: 250px;
            max-width: 80%;
            z-index: 1000;
            font-size: 16px;
            font-weight: bold;
        }

        /* Different Alert Colors */
        .success { background-color: #28a745; }  /* Green */
        .danger { background-color: #dc3545; }   /* Red */
        .warning { background-color: #ffc107; color: #333; }  /* Yellow */

        /* Close Button */
        .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            background: none;
            border: none;
            font-size: 18px;
            color: white;
            cursor: pointer;
        }

        .warning .close-btn { color: #333; } /* Close button color for warning */

        /* Fade-in & Fade-out Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -55%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }

        @keyframes fadeOut {
            from { opacity: 1; transform: translate(-50%, -50%); }
            to { opacity: 0; transform: translate(-50%, -55%); }
        }
</style>
<script>
    function showCustomAlert(alertId) {
        let alertBox = document.getElementById(alertId);
        alertBox.style.display = 'block';
        alertBox.style.animation = 'fadeIn 0.5s ease-in-out';

        // Auto-hide after 3 seconds
        setTimeout(() => {
            closeAlert(alertId);
        }, 3000);
    }

    function closeAlert(alertId) {
        let alertBox = document.getElementById(alertId);
        alertBox.style.animation = 'fadeOut 0.5s ease-in-out';
        setTimeout(() => {
            alertBox.style.display = 'none';
        }, 500);
    }
    function redirectToDashboard() {
            setTimeout(function () {
                window.location.href = '';
            }, 2000); // Redirect after 2 seconds
        }

</script>

<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blood_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    // Prepare the SQL statement to update the donor's information
    $sql = "UPDATE bdon SET donarname = ?, addres = ?, phone = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $address, $phone, $email);

    // Execute the statement
    if ($stmt->execute()) {
        echo '<div id="successAlert" class="custom-alert success">
                    <button class="close-btn" onclick="closeAlert(\'successAlert\')">✖</button>
                    <p>✅ Success! Your Profile was Updated successfully.</p>
                </div>';
        echo "<script>
                showCustomAlert('successAlert'); 
                setTimeout(function() { window.location.href = ''; }, 2000);
              </script>";
    } else {
        echo '<div id="dangerAlert" class="custom-alert danger">
                <button class="close-btn" onclick="closeAlert(\'dangerAlert\')">✖</button>
                <p>❌ Error!.</p>
              </div>';
        echo "<script>showCustomAlert('dangerAlert');</script>";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>
