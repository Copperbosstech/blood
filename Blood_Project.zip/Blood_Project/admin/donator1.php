<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Registration</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            background: linear-gradient(to right, #a1c4fd, #c2e9fb);
            padding: 20px;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        table {
            width: 100%;
            max-width: 1000px;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #3f51b5;
            color: white;
        }
    </style>
</head>
<body>

<h2>Donor List</h2>

<?php
$con = mysqli_connect('localhost', 'root', '', 'blood_db');
if (!$con) {
    die("<p style='color:red;'>Connection Failed: " . mysqli_connect_error() . "</p>");
}

// Fetch and display donors
$result = mysqli_query($con, "SELECT donarname, email, gender, addres, phone, city, bloodgroup, ldod, nod FROM bdon");

if (mysqli_num_rows($result) > 0) {
    echo "<table>
            <tr>
                <th>Donor Name</th>
                <th>Email</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Phone</th>
                <th>City</th>
                <th>Blood Group</th>
                <th>Last Donation</th>
                <th>Times Donated</th>
            </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['donarname']}</td>
                <td>{$row['email']}</td>
                <td>{$row['gender']}</td>
                <td>{$row['addres']}</td>
                <td>{$row['phone']}</td>
                <td>{$row['city']}</td>
                <td>{$row['bloodgroup']}</td>
                <td>{$row['ldod']}</td>
                <td>{$row['nod']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>No donors found.</p>";
}

mysqli_close($con);
?>

</body>
</html>
