<style>
    .donor-results {
    margin-top: 20px;
    width: 60%;
    text-align: center;
    padding: 20px;
    background: white;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    display: none;
}

.donor-card {
    background: white;
    padding: 15px;
    margin: 10px 0;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    text-align: left;
    opacity: 0;
    transform: translateY(20px);
    animation: fadeInUp 0.5s ease-in-out forwards;
}

.donor-card:hover {
    transform: scale(1.05);
    transition: transform 0.3s ease-in-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.donor-card h4 {
    margin: 0;
    font-size: 18px;
    color: #333;
}

.donor-card p {
    margin: 5px 0;
    color: #666;
    font-size: 14px;
}

</style>
<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "blood_db";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("<p style='color:red;'>Connection failed: " . $conn->connect_error . "</p>");
}

// Check if bloodGroup is set and not empty
if (isset($_GET['bloodGroup']) && !empty($_GET['bloodGroup'])) {
    $bloodGroup = $_GET['bloodGroup'];

    // Prepare SQL query
    $sql = "SELECT donarname, email, gender, addres, phone, city, ldod, nod FROM bdon WHERE bloodgroup = ?";
    
    // Prepare statement
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $bloodGroup);
        $stmt->execute();
        $result = $stmt->get_result();

        // Display results in table format
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='donor-card'>
                        <h4>" . htmlspecialchars($row['donarname']) . "</h4>
                        <p><strong>Email:</strong> " . htmlspecialchars($row['email']) . "</p>
                        <p><strong>Gender:</strong> " . htmlspecialchars($row['gender']) . "</p>
                        <p><strong>Address:</strong> " . htmlspecialchars($row['addres']) . "</p>
                        <p><strong>Phone:</strong> " . htmlspecialchars($row['phone']) . "</p>
                        <p><strong>City:</strong> " . htmlspecialchars($row['city']) . "</p>
                        <p><strong>Last Donation Date:</strong> " . htmlspecialchars($row['ldod']) . "</p>
                        <p><strong>Number of Donations:</strong> " . htmlspecialchars($row['nod']) . "</p>
                      </div>";
            }
        }
         else {
            echo "<p style='color:red;'>No donors found for the selected blood group.</p>";
        }

        $stmt->close();
    } else {
        // Debugging message for SQL errors
        echo "<p style='color:red;'>Error preparing statement: " . $conn->error . "</p>";
    }
} else {
    echo "<p style='color:red;'>Invalid request.</p>";
}

$conn->close();
?>
