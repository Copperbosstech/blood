function loadPage(page, element) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", page, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Clear previous content
            var contentTable = document.getElementById("content-table");
            contentTable.innerHTML = "";

            // If Team button is clicked, add "Our Team" heading in the center
            if (page === "team.html") {
                var heading = document.createElement("h2");
                heading.innerText = "Our Team";
                heading.style.marginBottom = "12px";
                heading.style.textAlign = "center";  // Center the text
                heading.style.fontSize = "30px";  // Increase font size
                heading.style.fontWeight = "bold"; // Make text bold
                contentTable.appendChild(heading);
            }

            // Load the requested page content
            contentTable.innerHTML += xhr.responseText;
        }
    };
    xhr.send();

    // Remove 'active' class from all links
    var links = document.querySelectorAll(".sidebar a");
    links.forEach(link => link.classList.remove("active"));

    // Add 'active' class to clicked link
    element.classList.add("active");

    // Clear any existing text in the content area
    document.getElementById("content-table").innerHTML = "";
}
