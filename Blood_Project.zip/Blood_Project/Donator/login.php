<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Blood Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<style>
    .custom-alert {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.3);
        display: none;
        text-align: center;
        min-width: 250px;
        max-width: 80%;
        z-index: 1000;
        font-size: 16px;
        font-weight: bold;
    }
    body {
        display: flex;
        justify-content: center;  /* Centers horizontally */
        align-items: center;      /* Centers vertically */
        height: 100vh;            /* Makes body take full viewport height */
        margin: 0;
        overflow:hidden;
    }
    
    .container {
        background: #fff;
        border-radius: 10px;
        padding: 30px;
        box-shadow: 0px 8px 16px rgba(5, 125, 224, 0.849);
        text-align: center;
        width: 350px;
        opacity: 1;
        animation: none;
    }
a{
    text-decoration: none;
}
a:hover{
    color: #dc3545;
}
    /* Alert Colors */
    .success { background-color: #28a745; }  /* Green */
    .danger { background-color: #dc3545; }   /* Red */
    .warning { background-color: #ffc107; color: #333; }  /* Yellow */

    /* Close Button */
    .close-btn {
        position: absolute;
        top: 10px;
        right: 15px;
        background: none;
        border: none;
        font-size: 18px;
        color: white;
        cursor: pointer;
    }

    .warning .close-btn { color: #333; } /* Close button color for warning */

    /* Fade-in & Fade-out Animation */
    @keyframes fadeIn {
        from { opacity: 0; transform: translate(-50%, -55%); }
        to { opacity: 1; transform: translate(-50%, -50%); }
    }

    @keyframes fadeOut {
        from { opacity: 1; transform: translate(-50%, -50%); }
        to { opacity: 0; transform: translate(-50%, -55%); }
    }
</style>
<body>
    <div class="container">
        <h2>Blood Management System</h2>
        <h3>Use your Profile</h3>
        <form id="loginForm" method="POST">
            <input type="email" id="email" name="email" placeholder="Email" required autocomplete="off">
            <input type="password" id="password" name="password" placeholder="Password" required autocomplete="off">
            <button type="submit" name="sub">Login</button>
        </form>
        <p>Don't have an account? <a href="sample2.php">Sign Up</a></p>
    </div>

    <!-- Custom Alerts -->
    <div id="dangerAlert" class="custom-alert danger">
        <button class="close-btn" onclick="closeAlert('dangerAlert')">✖</button>
        <p id="alertMessage">❌ Error! Something went wrong, please try again.</p>
    </div>

    <div id="successAlert" class="custom-alert success">
        <button class="close-btn" onclick="closeAlert('successAlert')">✖</button>
        <p id="successMessage">✅ Login Successful! Redirecting...</p>
    </div>

    <script>
        function showCustomAlert(message) {
            let alertBox = document.getElementById("dangerAlert");
            document.getElementById("alertMessage").innerText = message;
            alertBox.style.display = "block";
            alertBox.style.animation = "fadeIn 0.5s ease-in-out";

            setTimeout(() => {
                closeAlert("dangerAlert");
            }, 3000);
        }

        function showCustomSuccessAlert(message, redirectUrl) {
            let alertBox = document.getElementById("successAlert");
            document.getElementById("successMessage").innerText = message;
            alertBox.style.display = "block";
            alertBox.style.animation = "fadeIn 0.5s ease-in-out";

            setTimeout(() => {
                window.location.href = redirectUrl; // Redirect after 2 seconds
            }, 2000);
        }

        function closeAlert(alertId) {
            let alertBox = document.getElementById(alertId);
            alertBox.style.animation = "fadeOut 0.5s ease-in-out";
            setTimeout(() => {
                alertBox.style.display = "none";
            }, 500);
        }
    </script>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sub'])) { 
    session_start();
    $con = mysqli_connect('localhost', 'root', '', 'blood_db');

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $email = trim($_POST['email']);
    $pw = trim($_POST['password']);

    $sql = "SELECT * FROM bdon WHERE email = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        if (password_verify($pw, $row['password'])) {
            $_SESSION['email'] = $email;
            echo "<script>showCustomSuccessAlert('✅ Login Successful! Redirecting...', 'donatorhomepage.php');</script>";
        } else {
            echo "<script>showCustomAlert('❌ Incorrect password! Try again.');</script>";
        }
    } else {
        echo "<script>showCustomAlert('❌ Email not found! Please sign up first.');</script>";
    }

    $stmt->close();
    $con->close();
}
?>
