

<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$errormsg = isset($_SESSION['errormsg']) ? $_SESSION['errormsg'] : "";
$otpmsg = isset($_SESSION['otpmsg']) ? $_SESSION['otpmsg'] : "";

// Check if we need to show OTP message and redirect
$showOtpAndRedirect = isset($_SESSION['show_otp_and_redirect']) ? $_SESSION['show_otp_and_redirect'] : false;
unset($_SESSION['show_otp_and_redirect']);
unset($_SESSION['errormsg']);
unset($_SESSION['otpmsg']);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot password</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Montserrat', sans-serif;
}

body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: #fff;
}

/* Login Container */

.container {
    background: #fff;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0px 8px 16px rgba(5, 125, 224, 0.849);
    text-align: center;
    width: 350px;
    animation: fadeIn 1s ease-in-out;
}
/* .login-container {
    padding: 30px;
    width: 350px;
    border-radius: 15px;
    box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.3);
    text-align: center;
    animation: slideIn 1s ease-in-out;
} */

h1 {
    color: #333;
    font-weight: 600;
    margin-bottom: 20px;
}

/* Labels */
label {
    display: block;
    text-align: left;
    font-size: 14px;
    color: #333;
    margin: 10px 0 5px;
}

/* Input Fields */
input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background: #f9f9f9;
    color: #333;
    outline: none;
    transition: 0.3s ease-in-out;
}

input::placeholder {
    color: #888;
}

input:focus {
    background: #fff;
    transform: scale(1.05);
    border-left: 4px solid #27ae60;
}




/* Button */
button {
    width: 50%;
    padding: 10px;
    background: #ff5722;
    color: #fff;
    border: none;
    border-radius:20px;
    font-size: 20px;
    cursor: pointer;
    margin-top: 15px;
    transition: 0.3s ease-in-out;
}

button:hover {
    background: #ef0404;
    transform: scale(1.05);
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
}

.error { color: red; font-size: 14px; margin-top: 5px; }
.success { color: green; font-size: 16px; margin-top: 10px; }

/* Animation */
@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

</style>
<?php if ($showOtpAndRedirect && !empty($otpmsg)): ?>
    <script>
        setTimeout(function() {
            window.location.href = "otp.php";
        }, 2000);
    </script>
    <?php endif; ?>
    
</head>

<body>
    <div class="container">
        <form action="forgotpw.php" method="post">
            <h1>Forgot Password</h1>
            <label for="email">Enter Email</label>
            <input type="email" name="email" id="email" placeholder="Mail id" required><br>
            <?php if (!empty($errormsg)): ?>
                <span class="error"><?php echo $errormsg; ?></span>
            <?php endif; ?>
            <?php if (!empty($otpmsg)): ?>
                <p class="success"><?php echo $otpmsg; ?></p>
            <?php endif; ?>

            <button>Submit</button>
        </form>
       

    </div>
    


</body>
</html>




<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";  // Default for XAMPP
    $password = "";  
    $database = "usersignup"; // Your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the email from form input
    $email = trim($_POST['email']); // Trim to remove extra spaces

    // Prepared statement to check email in table1
    $stmt = $conn->prepare("SELECT id FROM table1 WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['email'] = $email;
        $_SESSION['otpmsg']= "OTP has been sent to your mail id:)";
        $_SESSION['show_otp_and_redirect'] = true;
        header("Location: forgotpw.php");
        exit();
    } else {
        $_SESSION['errormsg'] = "Invalid Email.Enter a registered email.";
        header("Location: forgotpw.php");
        exit();
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>









