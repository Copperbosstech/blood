<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; /* Changed to 100vh for proper centering */
        }

        .container {
            display: flex;
            width: 100%;
            max-width: 800px; /* Added max-width for better layout */
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0px 8px 16px rgba(5, 125, 224, 0.849);
            /* box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); */
        }


        .left-section, .right-section {
            flex: 1;
            padding: 30px;
        }

        .right-section {
            background: #e63946;
            color: white;
        }

        h2 {
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: none;
            border-bottom: 1px solid #ccc;
            background:none;
            outline: none;
            color: inherit;
        }
        .form-group select[name="bd"] {
    background-color: #ffcccc; /* Light red background */
    color: #333; /* Dark text for contrast */
    border: 1px solid #ff0000; /* Red border for emphasis */
    border-radius: 5px;
    padding: 10px;
    font-weight: bold;
}

/* Style individual options */
.form-group select[name="bd"] option {
    background-color: white; /* Background for options */
    color: black;
}

        .form-group input::placeholder {
            color: inherit;
            opacity: 0.6;
            font-size: 14px;
        }

        label {
            margin-bottom: 10px;
            font-size: 18px;
            font-weight: bold;
            color: #333;    
        }

        .checkbox {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }

        

        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        textarea {
             width: 100%; height: 80px; padding: 10px; font-size: 13px; border: 1px solid #ccc; border-radius: 5px; resize: vertical; transition: border-color 0.3s;
        }
        .login_link{
            color: blue; /* Change to your preferred color */
            font-weight: bold;
            text-decoration: none;
        }

        .register-button {
            background: white;
            color: #3f51b5;
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
        }

        h1 {
            color: red;
            text-align: center;
            margin-bottom: 30px;
        }

        

        .custom-alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.3);
            display: none;
            text-align: center;
            min-width: 250px;
            max-width: 80%;
            z-index: 1000;
            font-size: 16px;
            font-weight: bold;
        }

        .success { background-color: #28a745; }
        .danger { background-color: #dc3545; }
        .warning { background-color: #ffc107; color: #333; }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            background: none;
            border: none;
            font-size: 18px;
            color: white;
            cursor: pointer;
        }

        .warning .close-btn { color: #333; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translate(-50%, -55%); }
            to { opacity: 1; transform: translate(-50%, -50%); }
        }

        @keyframes fadeOut {
            from { opacity: 1; transform: translate(-50%, -50%); }
            to { opacity: 0; transform: translate(-50%, -55%); }
        }
        button{
            background: white;
            color: #3f51b5;
            padding: 10px 20px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-weight: bold;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<script>
    function showCustomAlert(alertId) {
        let alertBox = document.getElementById(alertId);
        alertBox.style.display = 'block';
        alertBox.style.animation = 'fadeIn 0.5s ease-in-out';

        setTimeout(() => {
            closeAlert(alertId);
        }, 3000);
    }

    function closeAlert(alertId) {
        let alertBox = document.getElementById(alertId);
        alertBox.style.animation = 'fadeOut 0.5s ease-in-out';
        setTimeout(() => {
            alertBox.style.display = 'none';
        }, 500);
    }

    function redirectToDashboard() {
        setTimeout(function () {
            window.location.href = 'login.php';
        }, 2000);
    }
</script>
<body>
<form action="#" method="post">
    <h1>Blood Donator Registration Form</h1>
    <div class="container">
        <div class="left-section">
            <h2>General Information</h2>
            <div class="form-group"><input type="text" placeholder="Name" name="nam" required autocomplete="off"></div>
            <div class="form-group">
                
                <select name="gen" required>
                    <option value="">...Select Gender...</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="form-group"><textarea id="adrs" name="adrs" placeholder="Address" required autocomplete="off"></textarea></div>

            <!-- <div class="form-group"><input type="text" name="adrs" placeholder="Address" required autocomplete="off"></div> -->
            <div class="form-group"><input type="text" name="city" placeholder="City" required autocomplete="off"></div>
            <div class="form-group"><input type="text" name="phone" placeholder="Phone" required autocomplete="off"></div>
        </div>
        <div class="right-section">
            <h2>Contact Details</h2>
            <div class="form-group"><input type="email" name="email" placeholder="Email" required autocomplete="off"></div>
            <div class="form-group"><input type="password" name="pw" placeholder="Password" required autocomplete="off"></div>
            <div class="form-group"><input type="password" name="cp" placeholder="Confirm Password" required autocomplete="off"></div>
            <div class="form-group">
                
                <select name="bd" required>
                    <option value="">...Select Blood Group...</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                </select>
            </div>
            <div class="form-group"><label for="ldod">Last Date of Donation</label> <input type="date" name="ldod" required autocomplete="off"></div>
            <div class="form-group"><input type="number" placeholder="Number of Times Donated" name="nod" required autocomplete="off"></div>
            
            <div class="button-container">
                <button class="register-button" type="submit" name="sub">Register Badge</button><br><br>
                <!-- <p>Already have account ? <button onclick="window.location.href='login.php'">Login</button></p> -->
            </div>
                <p>Already have an account? <a href="login.php" class="login-link" >Log in</a></p>



        </div>
    </div>
</form>

<?php
if (isset($_POST['sub'])) {
    function isEmailExists($con, $tableName, $em) {
        $sql = "SELECT * FROM " . $tableName . " WHERE email='" . $em . "'";
        $results = mysqli_query($con, $sql);
        $row = $results->fetch_assoc();
        return (is_array($row) && count($row) > 0);
    }

    function date_check($gen, $ldod) {
        $input_date_obj = new DateTime($ldod);
        $current_date_obj = new DateTime();
        $interval = $current_date_obj->diff($input_date_obj);
        $days_difference = $interval->days;
        if ($gen == 'Male' && $days_difference < 90) {
            return true;
        } elseif ($gen == 'Female' && $days_difference < 120) {
            return true;
        } else {
            return false;
        }
    }

    $con = mysqli_connect('localhost', 'root', '', '');
    if (!$con) {
        die("Connection Failed :" . mysqli_connect_error());
    }

    $sql = "CREATE DATABASE IF NOT EXISTS blood_db";
    mysqli_query($con, $sql);

    $q = "USE blood_db";
    mysqli_query($con, $q);

    $nam = $_POST['nam'];
    $em = $_POST['email'];
    $gen = $_POST['gen'];
    $adrs = $_POST['adrs'];
    $city = $_POST['city'];
    $phone = $_POST['phone'];
    $bd = $_POST['bd'];
    $ldod = $_POST['ldod'];
    $nod = $_POST['nod'];
    $pw = $_POST['pw'];
    $hpw = password_hash($pw, PASSWORD_DEFAULT);
    $cp = $_POST['cp'];

    if ($pw == $cp) {
        $query = "CREATE TABLE IF NOT EXISTS bdon(
            id INT AUTO_INCREMENT PRIMARY KEY,
            donarname VARCHAR(100) NOT NULL,
            email VARCHAR(255) NOT NULL UNIQUE,
            gender VARCHAR(255) NOT NULL,
            addres VARCHAR(255) NOT NULL,
            phone VARCHAR(100) NOT NULL UNIQUE,
            city VARCHAR(255) NOT NULL,
            bloodgroup VARCHAR(255) NOT NULL,
            ldod DATE NOT NULL,
            nod VARCHAR(255) NOT NULL,
            password VARCHAR(255) NOT NULL
        )";

        if (mysqli_query($con, $query)) {
            // Table created successfully
        } else {
            echo "Error creating table: " . mysqli_error($con);
            exit;
        }

        if (isEmailExists($con, "bdon", $em)) {
            echo '<div id="dangerAlert" class="custom-alert danger">
                <button class="close-btn" onclick="closeAlert(\'dangerAlert\')">✖</button>
                <p>❌ Error! Email already exists.</p>
            </div>';
            echo "<script>showCustomAlert('dangerAlert');</script>";
        } elseif (date_check($gen, $ldod)) {
            echo '<div id="dangerAlert" class="custom-alert danger">
                <button class="close-btn" onclick="closeAlert(\'dangerAlert\')">✖</button>
                <p>❌ Error! Cannot Donate.</p>
            </div>';
            echo "<script>showCustomAlert('dangerAlert');</script>";
        } else {
            $query = "INSERT INTO bdon (donarname, email, gender, addres, phone, city, bloodgroup, ldod, nod, password)
            VALUES ('$nam','$em','$gen','$adrs','$phone','$city','$bd','$ldod','$nod','$hpw')";

            if (mysqli_query($con, $query)) {
                echo '<div id="successAlert" class="custom-alert success">
                    <button class="close-btn" onclick="closeAlert(\'successAlert\')">✖</button>
                    <p>✅ Success! Your Profile was created successfully.</p>
                </div>';
                echo "<script>showCustomAlert('successAlert'); redirectToDashboard();</script>";
            } else {
                echo "Error: " . mysqli_error($con);
            }
        }
        mysqli_close($con);
    } else {
        echo '<script>alert("Error: Confirm Password Does not match!")</script>';
    }
}
?>
</body>
</html>