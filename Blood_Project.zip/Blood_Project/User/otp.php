<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>otp verification</title>
</head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    background: #fff;
}

.form-container {
    background: #fff;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0px 8px 16px rgba(5, 125, 224, 0.849);
    text-align: center;
    width: 350px;
    /* animation: fadeIn 1s ease-in-out; */
}

h1 {
    color: #333;
    margin-bottom: 15px;
    font-weight: 600;
    
}

label {
    display: block;
    text-align: left;
    color: #333;
    font-weight: 400;
    margin: 10px 0 5px;
}

input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background: #f9f9f9;
    color: #333;
    outline: none;
    transition: 0.3s ease-in-out;
}

input::placeholder {
    color: #888;
}

input:focus {
    background: #fff;
    transform: scale(1.05);
    border-color: #ff5722;
}

button {
    width: 50%;
    padding: 10px;
    background: #ff5722;
    color: #fff;
    border: none;
    border-radius:20px;
    font-size: 20px;
    cursor: pointer;
    margin-top: 15px;
    transition: 0.3s ease-in-out;
}

button:hover {
    background: #e64a19;
    transform: scale(1.05);
}

/* Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

</style>
<body>
    <div class="form-container">
        <form action="" method="post">
            <h1>Enter OTP</h1>
            <input type="text" name="username" placeholder="OTP" required><br>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>