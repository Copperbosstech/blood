<?php
session_start();
if (!isset($_SESSION['email'])) {  // Check if user is logged in
    header("Location: userlogin.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Home</title>
    <link rel="stylesheet" href="css/userhome.css">
    <script src="js/userhome.js"></script>
</head>
<body>
    <div class="sidebar">
        <div class="profile">
            <img src="person-100.png" alt="User Profile">  <!-- Profile Image -->
        </div>
        <h2>User Menu</h2>
        <a href="#" onclick="loadPage('donator1.php', this)">View Donors</a>
        <a href="#" onclick="loadPage('user_edit.php', this)">My Details</a>
        <a href="#" onclick="loadPage('search.php', this)">Search</a>
    </div>

    <div class="content">
        <div class="logout">
            <a href="logout.php">
                <img src="logout (1).png" alt="Logout">
            </a>
        </div>
        <h1>Welcome, User!</h1>

        <!-- Iframe for loading pages -->
        <iframe id="content-container" src="" frameborder="0"></iframe>
    </div>

    <script>
        function loadPage(page, element) {
            document.getElementById("content-container").src = page;

            // Highlight active link
            let links = document.querySelectorAll(".sidebar a");
            links.forEach(link => link.classList.remove("active"));
            element.classList.add("active");
        }
    </script>
</body>
</html>
