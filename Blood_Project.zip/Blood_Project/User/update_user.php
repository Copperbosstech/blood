<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    text-align: center;
    margin: 50px;
}

.custom-alert {
    padding: 15px;
    margin: 20px auto;
    border-radius: 5px;
    width: 50%;
    text-align: center;
    font-size: 18px;
    font-weight: bold;
}

.success {
    background-color: #4CAF50;
    color: white;
}

.error {
    background-color: #ff4d4d;
    color: white;
}

.close-btn {
    float: right;
    background: none;
    border: none;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

</style>
<script>
function closeAlert(id) {
    document.getElementById(id).style.display = 'none';
}

function redirectToDashboard() {
    setTimeout(function () {
        window.location.href = ' ';
    }, 2000); // Redirect after 2 seconds
}

</script>
<?php
session_start(); // Start session to access $_SESSION['email']

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "usersignup";

// Establish database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_SESSION['email'];
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);

    // Validate phone number (10-digit numeric)
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        echo "<script>alert('Invalid phone number. Please enter a valid 10-digit number.'); window.location.href='user_edit.php';</script>";
        exit();
    }

    // Update user details
    $sql = "UPDATE table1 SET phone = ?, address = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sss", $phone, $address, $email);

    if ($stmt->execute()) {
        echo '<div id="successAlert" class="custom-alert success">
                <button class="close-btn" onclick="closeAlert(\'successAlert\')">✖</button>
                <p>✅ Success! Redirecting to Dashboard...</p>
              </div>';
        echo "<script>redirectToDashboard();</script>";
    } else {
        echo '<div id="dangerAlert" class="custom-alert error">
                <button class="close-btn" onclick="closeAlert(\'dangerAlert\')">✖</button>
                <p>❌ Error! Something went wrong, please try again.</p>
              </div>';
    }

    $stmt->close();
}

$conn->close();
?>
