<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    text-align: center;
    margin: 50px;
}

.custom-alert {
    padding: 15px;
    margin: 20px auto;
    border-radius: 5px;
    width: 50%;
    text-align: center;
    font-size: 18px;
    font-weight: bold;
}

.success {
    background-color: #4CAF50;
    color: white;
}

.error {
    background-color: #ff4d4d;
    color: white;
}

.close-btn {
    float: right;
    background: none;
    border: none;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

.message {
    text-align: center;
    font-size: 20px;
    font-weight: bold;
    margin-top: 20px;
}

</style>
<script>
    function closeAlert(id) {
    document.getElementById(id).style.display = 'none';
}

function redirectToDashboard() {
    setTimeout(function () {
        window.location.href = 'userhome.php';
    }, 2000); // Redirect after 2 seconds
}

</script>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "usersignup");

    if ($conn->connect_error) {
        die("<p class='message error'>❌ Connection failed: " . $conn->connect_error . "</p>");
    }

    // Using prepared statements to prevent SQL Injection
    $stmt = $conn->prepare("SELECT * FROM table1 WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the user data
        $user = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Start a session and store user data
            session_start();
            $_SESSION['email'] = $user['email'];

            // Show success message and redirect
            echo "<div id='successAlert' class='custom-alert success'>
                    <button class='close-btn' onclick='closeAlert(\"successAlert\")'>✖</button>
                    <p>✅ Login Successful! Redirecting...</p>
                  </div>";
            echo "<script>redirectToDashboard();</script>";
        } else {
            // Incorrect password
            echo "<div id='dangerAlert' class='custom-alert error'>
                    <button class='close-btn' onclick='closeAlert(\"dangerAlert\")'>✖</button>
                    <p>❌ Incorrect password. Please try again.</p>
                  </div>";
        }
    } else {
        // User not found
        echo "<div id='dangerAlert' class='custom-alert error'>
                    <button class='close-btn' onclick='closeAlert(\"dangerAlert\")'>✖</button>
                    <p>❌ No account found with this email.</p>
                  </div>";
    }

    
    // Close connections
    $stmt->close();
    $conn->close();
}
?>

</body>
</html>
