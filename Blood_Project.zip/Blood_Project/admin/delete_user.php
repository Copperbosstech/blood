<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "usersignup");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if 'id' is set in the URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Prevent SQL injection

    // Delete query
    $deleteQuery = "DELETE FROM table1 WHERE id = ?";
    $stmt = mysqli_prepare($conn, $deleteQuery);
    mysqli_stmt_bind_param($stmt, "i", $id);

    if (mysqli_stmt_execute($stmt)) {
        // Redirect back with a success message
        header("Location: admin_dashboard.php?status=success");
        exit();
    } else {
        // Redirect back with an error message
        header("Location: users_list.php?status=error");
        exit();
    }

    mysqli_stmt_close($stmt);
}

// Close connection
mysqli_close($conn);
?>
