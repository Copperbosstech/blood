document.addEventListener("DOMContentLoaded", function () {
    // Define blood type limits
    const bloodTypes = {
        "A+": 1024,
        "A-": 512,
        "B+": 640,
        "B-": 320,
        "AB+": 128,
        "AB-": 64,
        "O+": 2048,
        "O-": 1024,
    };

    const container = document.querySelector('.blood-container');
    const bloodGroupElements = {};

    // Create blood type counters
    for (const [type, limit] of Object.entries(bloodTypes)) {
        const div = document.createElement('div');
        div.className = 'blood-group';

        const countSpan = document.createElement('div');
        countSpan.className = 'blood-count';
        countSpan.textContent = "0"; // Start from 0

        const label = document.createElement('div');
        label.className = 'blood-label';
        label.textContent = type;

        div.appendChild(countSpan);
        div.appendChild(label);
        container.appendChild(div);

        bloodGroupElements[type] = { countSpan, limit, current: 0 };
    }

    // Update counts like a stopwatch
    function updateCounts() {
        let allCompleted = true;

        for (const [type, { countSpan, limit, current }] of Object.entries(bloodGroupElements)) {
            if (current < limit) {
                allCompleted = false;
                bloodGroupElements[type].current += 10; // Increment by 10
                if (bloodGroupElements[type].current > limit) {
                    bloodGroupElements[type].current = limit;
                }
                countSpan.textContent = bloodGroupElements[type].current;
            }
        }

        // Stop the interval if all counts are completed
        if (allCompleted) {
            clearInterval(intervalId);
        }
    }

    // Start the stopwatch
    const intervalId = setInterval(updateCounts, 100); // Update every 100ms
});

// const text = "Welcome to Blood Donation Mangement Project";
//         const h2Element = document.getElementById("animated-text");

//         let currentIndex = 0;

//         function animateText() {
//             if (currentIndex < text.length) {
//                 h2Element.textContent += text[currentIndex];
//                 currentIndex++;
//                 setTimeout(animateText, 100); // Adjust speed by changing 100ms
//             }
//         }

//         // Start the animation when the page loads
//         window.onload = animateText;
