<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "usersignup");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle delete request
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $deleteQuery = "DELETE FROM table1 WHERE id = $id";
    if (mysqli_query($conn, $deleteQuery)) {
        echo "<script>alert('User deleted successfully!'); window.location.href='users.php';</script>";
    } else {
        echo "<script>alert('Error deleting user.');</script>";
    }
}

// Fetch users from database
$sql = "SELECT * FROM table1";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users List</title>
    <style>
        * {
            font-family: Arial, sans-serif;
        }

        .container {
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background: #2c3e50;
            color: white;
        }

        .btn {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
            color: white;
            display: inline-block;
        }

        .view-btn {
            background: transparent;
        }

        .delete-btn {
            background: transparent;
        }

        .btn:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Users List</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>

            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['gender']}</td>
                        <td>{$row['address']}</td>
                        <td>{$row['phone']}</td>
                        <td>{$row['email']}</td>
                        <td>

                            <a href='view_user.php?id={$row['id']}' class='btn view-btn'><img src='view.png' alt='View' width='40' height='40'></a>
                            
                            <a href='users.php?delete={$row['id']}' class='btn delete-btn' onclick='return confirm(\"Are you sure?\")'><img src='delete.png' alt='Delete' width='40' height='40'></a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No users found</td></tr>";
            }

            // Close connection
            mysqli_close($conn);
            ?>
        </table>
    </div>
</body>
</html>
