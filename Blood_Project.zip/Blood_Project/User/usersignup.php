<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Process</title>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        text-align: center;
        margin: 50px;
    }
    .custom-alert {
        padding: 15px;
        margin: 20px auto;
        border-radius: 5px;
        width: 50%;
        text-align: center;
        font-size: 18px;
        font-weight: bold;
    }
    .success {
        background-color: #4CAF50;
        color: white;
    }
    .error {
        background-color: #ff4d4d;
        color: white;
    }
    .close-btn {
        float: right;
        background: none;
        border: none;
        color: white;
        font-size: 16px;
        cursor: pointer;
    }
    .message {
        text-align: center;
        font-size: 20px;
        font-weight: bold;
        margin-top: 20px;
    }
</style>
<script>
    function closeAlert(id) {
        document.getElementById(id).style.display = 'none';
    }

    function redirectToDashboard() {
        setTimeout(function () {
            window.location.href = 'userlogin.html';
        }, 2000); // Redirect after 2 seconds
    }
</script>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $gender = $_POST['gen'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $cpass = $_POST['cpassword'];

    // Database connection
    $conn = mysqli_connect("localhost", "root", "");

    if (!$conn) {
        die("<div class='custom-alert error'>
                <button class='close-btn' onclick='closeAlert(\"errorAlert\")'>✖</button>
                <p>❌ Database connection failed: " . mysqli_connect_error() . "</p>
              </div>");
    }

    // Create database if not exists
    $db_query = "CREATE DATABASE IF NOT EXISTS usersignup";
    if (!mysqli_query($conn, $db_query)) {
        die("<div class='custom-alert error'>
                <button class='close-btn' onclick='closeAlert(\"errorAlert\")'>✖</button>
                <p>❌ Error creating database: " . mysqli_error($conn) . "</p>
              </div>");
    }

    // Select the database
    mysqli_select_db($conn, "usersignup");

    // Create table if not exists
    $db_table = "CREATE TABLE IF NOT EXISTS table1 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        gender VARCHAR(10) NOT NULL,
        address TEXT NOT NULL,
        phone VARCHAR(15) NOT NULL UNIQUE,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
    )";

    if (!mysqli_query($conn, $db_table)) {
        die("<div class='custom-alert error'>
                <button class='close-btn' onclick='closeAlert(\"errorAlert\")'>✖</button>
                <p>❌ Error creating table: " . mysqli_error($conn) . "</p>
              </div>");
    }

    // Validate password match
    if ($pass !== $cpass) {
        echo "<div id='dangerAlert' class='custom-alert error'>
                <button class='close-btn' onclick='closeAlert(\"dangerAlert\")'>✖</button>
                <p>❌ Passwords do not match!</p>
              </div>";
    } else {
        // Escape special characters to prevent SQL injection
        $name = mysqli_real_escape_string($conn, $name);
        $gender = mysqli_real_escape_string($conn, $gender);
        $address = mysqli_real_escape_string($conn, $address);
        $phone = mysqli_real_escape_string($conn, $phone);
        $email = mysqli_real_escape_string($conn, $email);
        $hashed_pass = password_hash($pass, PASSWORD_BCRYPT); // Secure password hashing

        // Insert user data
        $insert = "INSERT INTO table1 (name, gender, address, phone, email, password) 
                   VALUES ('$name', '$gender', '$address', '$phone', '$email', '$hashed_pass')";

        if (mysqli_query($conn, $insert)) {
            echo "<div id='successAlert' class='custom-alert success'>
                    <button class='close-btn' onclick='closeAlert(\"successAlert\")'>✖</button>
                    <p>✅ Success! Redirecting to Login Page...</p>
                  </div>";
            echo "<script>redirectToDashboard();</script>";
        } else {
            echo "<div class='custom-alert error'>
                    <button class='close-btn' onclick='closeAlert(\"errorAlert\")'>✖</button>
                    <p>❌ Error! " . mysqli_error($conn) . "</p>
                  </div>";
        }
    }

    // Close the connection
    mysqli_close($conn);
}
?>

</body>
</html>
