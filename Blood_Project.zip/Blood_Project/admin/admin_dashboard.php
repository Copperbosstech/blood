<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: adminlogin.html");
    exit();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="css/admindashboard.css">
</head>
<body>
    <div class="sidebar">
        <div class="profile">
            <img src="images/admin-100.png" alt="Admin Profile">  
            <h2>Admin</h2>
        </div>
        <a href="#" onclick="loadPage('users.php', this)">Users</a>
        <a href="#" onclick="loadPage('donator1.php', this)">Donators</a>
        <a href="#" onclick="loadPage('team.html', this)">Team</a>
    </div>

    <div class="content">
        <div class="logout">
            <a href="logout.php"> <!-- Link to logout script -->
                <img src="images/logout (1).png" alt="Logout">
            </a>
        </div>
        <div id="content-table"></div>
    </div>

    <script src="js/admindashboard.js"></script>
</body>
</html>
