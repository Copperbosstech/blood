<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Donor Search</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .search-container {
            position: relative;
            display: flex;
            align-items: center;
            background: white;
            border-radius: 50px;
            padding: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease-in-out;
            width: 50px;
            overflow: hidden;
            cursor: pointer;
        }
        .search-container.active {
            width: 250px;
        }
        .search-container select {
            border: none;
            outline: none;
            padding: 10px;
            font-size: 16px;
            border-radius: 50px;
            appearance: none;
            cursor: pointer;
            flex-grow: 1;
            display: none;
        }
        .search-container.active select {
            display: block;
        }
        .icon {
            cursor: pointer;
            padding: 10px;
            font-size: 18px;
            transition: transform 0.3s ease-in-out;
        }
        .search-container.active .icon {
            transform: rotate(90deg);
        }
        .donor-results {
            margin-top: 20px;
            width: 60%;
            text-align: center;
            padding: 20px;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="search-container" id="searchBox">
        <select name="blood" id="blood">
            <option value="">Select Blood Group</option>
            <option value="O+">O+</option>
            <option value="B+">B+</option>
            <option value="A+">A+</option>
            <option value="AB+">AB+</option>
            <option value="O-">O-</option>
            <option value="B-">B-</option>
            <option value="A-">A-</option>
            <option value="AB-">AB-</option>
        </select>
        <span class="icon" id="searchIcon">🔍</span>
    </div>

    <div class="donor-results" id="donorResults">
        <h3>Donor Details</h3>
        <div id="results"></div>
    </div>

    <script>
        document.getElementById("searchIcon").addEventListener("click", function() {
            let searchBox = document.getElementById("searchBox");
            let bloodGroupSelect = document.getElementById("blood");

            searchBox.classList.toggle("active");

            if (searchBox.classList.contains("active")) {
                bloodGroupSelect.focus();
            } else {
                bloodGroupSelect.value = "";
                document.getElementById("donorResults").style.display = "none";
            }
        });

        document.getElementById("blood").addEventListener("change", function() {
            let bloodGroup = this.value;
            let resultsContainer = document.getElementById("donorResults");
            let resultsDiv = document.getElementById("results");

            if (bloodGroup) {
                fetch("donordisplay.php?bloodGroup=" + encodeURIComponent(bloodGroup)) 
                    .then(response => response.text())
                    .then(data => {
                        resultsDiv.innerHTML = data;
                        resultsContainer.style.display = "block";
                    })
                    .catch(error => console.error("Error fetching donors:", error));
            } else {
                resultsContainer.style.display = "none";
            }
        });
    </script>
</body>
</html>
