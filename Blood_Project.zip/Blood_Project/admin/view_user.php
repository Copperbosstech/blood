<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "usersignup");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user details
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM table1 WHERE id = $id";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);
} else {
    echo "<script>alert('User not found!'); window.location.href='users.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View User</title>
    <style>
        .container {
            padding: 20px;
            background: white;
            max-width: 500px;
            margin: 20px auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
        }

        p {
            font-size: 18px;
            margin: 10px 0;
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Details</h2>
        <p><strong>Name:</strong> <?= $user['name'] ?></p>
        <p><strong>Gender:</strong> <?= $user['gender'] ?></p>
        <p><strong>Address:</strong> <?= $user['address'] ?></p>
        <p><strong>Phone:</strong> <?= $user['phone'] ?></p>
        <p><strong>Email:</strong> <?= $user['email'] ?></p>
        <a href="admin_dashboard.html" class="back-btn">Back to Dashboard</a>

    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
