<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blood_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect if not logged in
    exit();
}

$email = $_SESSION['email'];

$sql = "SELECT * FROM bdon WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $donor = $result->fetch_assoc();
} else {
    echo "Donor not found.";
    exit();
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Donor Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px #ccc;
            width: 300px;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input[type="text"], input[type="email"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            margin-top: 15px;
            width: 100%;
            padding: 10px;
            border: none;
            background: #3498db;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Donor Profile</h2>
        <form action="updatedonor.php" method="POST">
            <label for="name">Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($donor['donarname']); ?>" required>
            
            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($donor['email']); ?>" readonly>
            
            <label for="address">Address:</label>
            <input type="text" name="address" value="<?php echo htmlspecialchars($donor['addres']); ?>" required>
            
            <label for="phone">Phone:</label>
            <input type="text" name="phone" value="<?php echo htmlspecialchars($donor['phone']); ?>" required>
            
            <label for="donate">Last Donation :</label>
            <input type="date" name="ldod" value="<?php echo htmlspecialchars($donor['ldod']); ?>" required>

            <label for="donations">Total Donations:</label>
            <input type="number" name="nod" value="<?php echo htmlspecialchars($donor['nod']); ?>" required>
            
            
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>